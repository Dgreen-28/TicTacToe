import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;

public class TTTPanel extends JPanel {

    private TTTFrame frame;
    private TTTLabel[][] buttons = new TTTLabel[3][3];

    public TTTPanel(TTTFrame frame) {

        this.frame = frame;
        setLayout(new GridLayout(3, 3));
        buildButtons();
    }

    private void buildButtons() {

        for (int r = 0; r < buttons.length; r++) {
            for (int c = 0; c < buttons[r].length; c++) {
                buttons[r][c] = new TTTLabel(r, c);
                add(buttons[r][c]);
            }
        }
    }

    private class TTTLabel extends JLabel {

        private int r, c;

        public TTTLabel(int r, int c) {
            this.r = r;
            this.c = c;
            addMouseListener(new TTTController());
            Border border = BorderFactory.createLineBorder(Color.BLACK);
            setBorder(border);
        }

        public void paintComponent(Graphics g) {
            super.paintComponent(g);

            g.setFont(new Font("Serif", Font.BOLD, 30));
            g.drawString("" + frame.getModel().getBoard()[r][c], getWidth() / 2, getHeight() / 2);
        }

        private class TTTController extends MouseAdapter {

            public void mouseClicked(MouseEvent e) {
                int winner = frame.getModel().makeMove(r, c);
                repaint();
                if (winner != TTTModel.NO_WINNER) {
                    if (winner == TTTModel.CAT_WIN) {
                        JOptionPane.showMessageDialog(null, "Cat Wins!");
                    } else {
                        JOptionPane.showMessageDialog(null, winner == TTTModel.X_WIN ? "X Wins!" : "O Wins!");
                    }
                }
            }

        }
    }
}