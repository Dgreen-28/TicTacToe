
import javax.swing.*;
import java.awt.*;
public class TTTFrame extends JFrame {

    TTTModel model;

    public TTTFrame() {

        setTitle("Tic Tak Toe");
        setSize(800, 900);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        model = new TTTModel();
        TTTPanel panel = new TTTPanel(this);
        add(panel);
        setVisible(true);
    }

    public TTTModel getModel() {
        return model;
    }
}