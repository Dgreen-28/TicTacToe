
import java.util.*;

public class TTTModel {

    public static int X_WIN = 0;
    public static int O_WIN = 1;
    public static int CAT_WIN = 2;
    public static int NO_WINNER = 3;

    private char[][] board = new char[3][3];
    private boolean xTurn;
    private int totalTurns;

    public TTTModel() {

        initialize();
        xTurn = true;
        totalTurns = 0;
    }

    private void initialize() {
        for (int r = 0; r < board.length; r++) {
            for (int c = 0; c < board[r].length; c++) {
                board[r][c] = ' ';
            }
        }
    }

    public int makeMove(int r, int c) {
        if (board[r][c] == ' ' && xTurn) {
            board[r][c] = 'X';
        } else if (board[r][c] == ' ' && !xTurn) {
            board[r][c] = 'O';
        }
        totalTurns++;
        int toReturn = isGameWon();
        xTurn = !xTurn;
        return toReturn;
    }

    private int isGameWon() {

        if (checkColumns() || checkRows() || checkDiagonal()) {
            if (xTurn)
                return X_WIN;
            else
                return O_WIN;
        }
        if (totalTurns == 9)
            return CAT_WIN;
        return NO_WINNER;
    }

    private boolean checkColumns() {
        for (int i = 0; i < board.length; i++) {
            if ((board[0][i] == board[1][i] && board[1][i] == board[2][i]) && board[0][i] != ' ')
                return true;
        }
        return false;
    }

    private boolean checkRows() {
        for (int i = 0; i < board.length; i++) {
            if ((board[i][0] == board[i][1] && board[i][1] == board[i][2]) && board[i][0] != ' ')
                return true;
        }
        return false;
    }

    private boolean checkDiagonal() {
        if (((board[0][0] == board[1][1] && board[1][1] == board[2][2])
                || (board[0][2] == board[1][1] && board[1][1] == board[2][0])) && board[1][1] != ' ')
            return true;
        return false;
    }

    private void printBoard() {
        for (int r = 0; r < board.length; r++) {
            for (int c = 0; c < board[r].length; c++) {
                System.out.print(" | " + board[r][c] + " | ");
            }
            System.out.println();
            System.out.println();
        }
    }

    public char[][] getBoard() {
        return board;
    }

    public static void main(String[] args) {
        TTTModel model = new TTTModel();
        Scanner scan = new Scanner(System.in);

        while (true) {

            model.printBoard();
            System.out.println("Make move");
            int winner = model.makeMove(scan.nextInt(), scan.nextInt());
            scan.nextLine();

            if (winner == X_WIN) {
                System.out.println("X wins");
                break;
            } else if (winner == O_WIN) {
                System.out.println("O wins");
                break;
            } else if (winner == CAT_WIN) {
                System.out.println("Cat wins");
                break;
            }
        }

        scan.close();
    }
}