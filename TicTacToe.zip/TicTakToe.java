import javax.swing.*;
public class TicTakToe {

    public static void main(String[] args) {

        new TTTFrame();
    }
}